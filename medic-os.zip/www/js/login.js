$(document).ready(function(){
    socket.on("loggin",function(datos){
        //console.log("loggin: ",datos)
        if(datos.success==true){
          usuario.usuario = datos.usuario;
          usuario.email_usuario = datos.email_usuario;
          usuario.config_k = datos.config_k;          
          usuario.nombre = datos.nombre;
          
          usuario.usuario_k = datos.usuario_k;
          usuario.area_k = datos.area_k;
          usuario.especialidad_k = datos.area_k;
          usuario.especialidad = datos.especialidad;
          usuario.foto = datos.foto;
            
          usuario.prefix = datos.prefix;
          usuario.clinica = datos.clinica;          
          usuario.pagina="menu";
          usuario.aplicacion_parent_k = 6;
          activate_page("#menu");  
            
          //$("#btns_carusel_menu").empty(); 
          //$("#btns_citas_menu").empty();
          //$("#btns_pacientes_menu").empty();
            
          socket.emit('identificacion', usuario); 
          //return false;
        }else{          
          mensaje = {mensaje:"No Tiene Autorización",success:false};
          delServidor(mensaje);
          activate_page("#mainpage"); 
            return false;
        } 
    });
    /* viene despues de identificar al usuario solicitado desde menú */
    socket.on('validarAccesoMenu', function(datos) {        
        var data = datos.respuesta_acceso,
        total = data.length;
        for(var i=0;i<total;i++){
            var nombre = data[i].cod_ac;
            var acceso = data[i].valor;
            var sugest = data[i].permisos_cod;
            if(nombre=="acceder" && acceso == "false"){
                activate_page(data[i].menu_href); 
            }
            if(nombre == "crear_citas" && acceso=="true"){

            }else if(nombre == "crear_citas" && acceso=="false"){

            }
            if(nombre == "acceso_select" && acceso=="true"){
                $("#seccion_a").empty(); 
                usuario.menus.seleccionar=true;     
                var area_medico = '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="height:50%;">'+
                                    '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="float:left;">'+
                                        '<label class="narrow-control label-top-left text-white" style="margin-left: 10px;">Areas</label>'+
                                        '<select style="border-radius:20px;width:100%;padding:10px;" id="areas" class="">'+
                                            "<option data-sugest='"+sugest+"' value="+usuario.area_k+">"+usuario.area+"</option>"+
                                        '</select>'+
                                    '</div>'+
                                    '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="float:left;height: 90px;">'+
                                        '<label class="narrow-control label-top-left text-white"" style="margin-left: 10px;">Personal</label>'+
                                        '<select style="border-radius:20px;width:100%;padding:10px;" id="nombreDr" class="">'+
                                            "<option data-sugest='"+sugest+"' value="+usuario.config_k+">"+usuario.usuario_nombre+"</option>"+
                                        '</select>'+
                                    '</div>'+
                                   '</div>'+
                                   '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="height:100%;">'+
                                    '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="float:left;height:60px;">'+
                                        '<button class="btn btn-sm btn-primary display-4" id="guardarOrden" style="border-radius:30px;width:95%;margin: 0px;">Guardar</button>'+
                                    '</div>'+
                                    '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="float:left;height:60px;">'+
                                        '<button class="btn btn-sm btn-primary display-4" id="restablecerOrden" style="border-radius:30px;width:95%;margin: 0px;">Restablecer</button> '+
                                    '</div>'+
                                '</div>';

                $("#seccion_a").append(area_medico); 
                $(".fc-month-button").click();
                $("#areas").bind( "change", function() {
                    cargarMedicos($(this).val());
                });
                $("#nombreDr").bind( "change", function() {
                    cargarMedicosData($(this).val());
                    usuario.citas.doctor_k=$(this).val();
                    if($(this).val()==usuario.doctor_k){
                        usuario.changeDoctor = 0;
                    }else {
                        usuario.changeDoctor = 1;
                    }
                    agendaMenu();
                    $(".fc-month-button").click();
                });
                $("#restablecerOrden").bind( "click", function() {
                    agendaMenu();
                });
        //agendaMenu(); 07/06/2018 desactivado
            }else if(nombre == "acceso_select" && acceso=="false"){
                $("#seccion_a").empty();
                usuario.menus.seleccionar=false;
                var area_medico =  '<div class="form-group col-sm-6" style="float:left;">'+
                "<div >"+
                "<label class='text-primary' for='areas'>&Aacute;rea</label>"+
                "<select class='form-control' id='areas' style='width: 100%;'>"+
                "<option value="+usuario.area_k+">"+usuario.area+"</option>"+
                "</select>"+
                "</div>"+
                "</div>"+
                "<div class='form-group col-sm-6' style='float:left;'>"+
                "<label class='text-primary' >M&eacute;dico</label>"+
                "<select class='form-control' id='nombreDr' style='width: 100%;'>"+
                "<option value="+usuario.config_k+">"+usuario.usuario_nombre+"</option>"+
                "</select>"+
                "</div>";
                $("#seccion_a").append(area_medico);
                //agendaMenu();
                $(".fc-month-button").click();
            }
            if(nombre == "cambiar_citas" && acceso=="true"){
                $("#btn_guardarOrden").empty();
                var btn = '<button type="button" id="guardarOrden" style="left:10px;position: absolute;" class="btn btn-light">Guardar</button>';
                
                var btn = '<button class="btn widget uib_w_56 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1" id="guardarOrden">Guardar</button>';
                
                $("#btn_guardarOrden").append(btn);
                $("#guardarOrden").bind("click",function(){
                    guardarOrden();
                });
            }else if(nombre == "cambiar_citas" && acceso=="false"){
                var btn = '<button type="button" style="left:10px;position: absolute;" class="btn btn-light" disabled>Guardar</button>';
                $("#btn_menu0").append(btn);
            }
            if(i+1 == total){
                if(usuario.menus.seleccionar==true){
                    usuario.area_k=0;
                    socket.emit("cargarAreas",usuario);
                }
            }
        }        
    });
    socket.on('areasClinicas',function (data){
        $("#nombreDr").empty();
        $("#areas").empty();
        for(var i = 0; i<data.data.length;i++){
            var area = '<option value="'+data.data[i].area_k+'" style="font-size:1em">'+data.data[i].nombre+'</option>';
            $("#areas").append(area);
            if(i+1 == data.data.length){
                $("#areas option[value='"+usuario.area_k+"']").attr('selected', true);                
                cargarMedicos(usuario.especialidad_k);
            }
        } 
    });
    $("#inputEmail").keypress(function(){
        var usuario = $("#inputEmail").val();
        //console.log(usuario.trim());
        socket.emit('identify', usuario.trim());
    });
 $("#menu0").fadeTo(0000,1,function(){});
  $("#inicio").click();

  $("#pacientes").on("click",function(e){
    $("#menu0").fadeTo(1000,0,
      function(){
        $("#menu0").css("display","none");
        $("#c_navbar").fadeTo(1000,1,function(){});
        $("#c_navbar").css("display","");
        $("#admin_pacientes_app").fadeTo(1000,1,function(){});
      });
    });
    
  $("#inicio").on("click",function(e){
  	$("#admin_pacientes_app").fadeTo(1000,1,
      function(){
        $("#admin_pacientes_app").css("display","none");
        $("#c_navbar").fadeTo(0,0,function(){});
        $("#c_navbar").css("display","none");
        $("#menu0").fadeTo(1000,1,function(){});
      });
  });
  socket.on("accesoSolicitado",function(datos){
     socket.emit('identificacion', usuario);
  });
  /*socket.on("message",function(datos){

  });*/
    socket.on("obtenerAccion", function(datos){
        //console.log("Obtener Accion-> ",datos);
    });
    socket.on("validarMenu",function(data){
        if(data.pagina=="Examen Fisico"){
            activate_page("#3b");  
            location.href="#3b";
            liberarDatos("#3b");
			/*openExamen("null", "Patologicos");
			nuevosRegistrosPreclinica();
			socket.emit("getPreclinica",data);
			usuario.paciente_k=$("#paciente_k").val();
			socket.emit("historialGlucosa",usuario);*/
            return false;
		}
    });
});

function foto_usuario(datos){
  //console.log("message: ",datos);
  $(".user-image_m").attr("src",datos.url_user);

}
function btnMenu(data){    
    usuario.cod = $(data).attr("id");
    usuario.aplicacion_parent_k = $(data).attr("data-app");
    usuario.pagina = $(data).attr("data-name");
    socket.emit("solicitudAcceso",usuario); 
}
/*function btnAccion(data){
  usuario.accion = $(data).attr("data-nombre");
  usuario.cod_ac = $(data).attr("data-accion");
  usuario.cod = $(data).attr("id");
  socket.emit("solicitudAcceso",usuario);
}*/

function bloquearDatos(tab){
	//console.log("Bloqueando datos: ",tab);
	$.each($(tab+" input"),function(item,index){
		$(index).attr("disabled",true);
	});
	$.each($(tab+" dir_textarea"),function(item,index){
		//$(index).attr("disabled",true);
    if($(index).data("wysihtml5")){
      $(index).data("wysihtml5").editor.composer.disable();
    }else{
      $(index).attr('disabled','disabled');
    }
	});
	$.each($(tab+" select"),function(item,index){
		$(index).attr("disabled",true);
	});
}
function liberarDatos(tab){
	//console.log("Liberando campos");
	$.each($(tab+" input"),function(item,index){
		$(index).attr("disabled",false);
	});
	$.each($(tab+" dir_textarea"),function(item,index){
		$(index).data("wysihtml5").editor.composer.enable();
	});
	$.each($(tab+" select"),function(item,index){
		$(index).attr("disabled",false);
	});
}
function validarMenu(data){
	var tab = $(data).attr("href");
	bloquearDatos(tab);
	/*if($("#femenino").prop("checked")==true){
		$("#femeninof").prop("checked",true);
		$("#masculinof").prop("checked",false);
		$("#antecedentes_femeninos").css("display","");
	}else if($("#femenino").prop("checked")!=true){
		$("#masculinof").prop("checked",true);
		$("#femeninof").prop("checked",false);
		$("#antecedentes_femeninos").css("display","none");
	}*/

	usuario.menu	= $(data).attr("name");
	usuario.cod 	= $(data).attr("id");
	usuario.pagina	= $(data).attr("data-pagina");
    //console.log("Validar Menu-> ",usuario);
	socket.emit("validarMenu",usuario);
}
